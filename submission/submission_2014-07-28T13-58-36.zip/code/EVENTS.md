17:55 24.07 - %    =     \...o.....

15:19 25.07 - Contest started. Some is reading task, someone still is working on other projects but all already thinking about Lambda-Man. #stanfy #icfp2014 hash tags to use in twitter %)

18:31 25.07 - Team is reading doc and start to say first assumptions

19:56 25.07 - Started working on:
1) Clojure compiler to Lambda-Man language (Java, ANTLR, etc)
2) Submission structure
3) Will solve task on Clojure at the end
4) Will run solution on their Javascript emulator
5) Go!!!