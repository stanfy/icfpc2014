package com.stanfy.icfp2014.translator.listeners;

import java.util.ArrayList;

/**
 * Created by ptaykalo on 7/26/14.
 */
public class ECMAFunction {

  public String name;
  public ArrayList<String> variables;

}
