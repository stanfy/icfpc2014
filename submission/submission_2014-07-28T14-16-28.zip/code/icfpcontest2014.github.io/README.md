This is the official site for the [ICFP Programming Contest
2014](http://icfpcontest.org)
