package com.stanfy.icfp2014.lambdaprocessor;

/**
 * Created by ptaykalo on 7/26/14.
 */
public class TAGSTOP {
}
