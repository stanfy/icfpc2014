package com.stanfy.icfp2014.translator.listeners;

/**
 * Created by ptaykalo on 7/26/14.
 */
public class ECMAVariable {
  public String name;

  @Override
  public String toString() {
    return "ECMAVariable{" +
        "name='" + name + '\'' +
        '}';
  }
}
